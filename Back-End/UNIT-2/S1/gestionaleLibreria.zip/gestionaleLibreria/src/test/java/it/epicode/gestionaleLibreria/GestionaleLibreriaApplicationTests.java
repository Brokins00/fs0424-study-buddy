package it.epicode.gestionaleLibreria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionaleLibreriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
