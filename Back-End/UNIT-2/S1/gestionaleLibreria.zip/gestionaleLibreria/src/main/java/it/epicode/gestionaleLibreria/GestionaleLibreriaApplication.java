package it.epicode.gestionaleLibreria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionaleLibreriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionaleLibreriaApplication.class, args);
	}

}
